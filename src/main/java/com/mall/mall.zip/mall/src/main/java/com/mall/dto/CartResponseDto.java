package com.mall.dto;

public class CartResponseDto {
	private String id;
	private String name;
	

	public String getId() {
		return id;
	}
	public void setId(String string) {
		this.id = string;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public CartResponseDto(String id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	public CartResponseDto() {
		
	}
	
	

}
